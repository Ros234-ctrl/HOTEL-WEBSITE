const mongoose=require("mongoose");
uri="mongodb+srv://kerkettaroshan650:znmdrs#234@cluster0.ntkk3gd.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";


const connectDB=()=> {

console.log("connect db")
     return mongoose.connect(uri,{
          useNewUrlParser:true,
          useUnifiedTopology:true,
          
});
};
module.exports=connectDB;
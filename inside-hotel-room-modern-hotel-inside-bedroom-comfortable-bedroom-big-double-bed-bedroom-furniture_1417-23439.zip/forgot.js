document.getElementById('passwordRecoveryForm').addEventListener('submit', function(event) {
  event.preventDefault();
  
  var email = document.getElementById('email').value;
  
  // Simulate sending email (replace with actual functionality)
  if (email) {
    // Assuming a successful recovery message
    var message = "Password reset link sent to " + email;
    document.getElementById('message').textContent = message;
    document.getElementById('email').value = ''; // Clear email input
  } else {
    document.getElementById('message').textContent = "Please enter your email";
  }
});

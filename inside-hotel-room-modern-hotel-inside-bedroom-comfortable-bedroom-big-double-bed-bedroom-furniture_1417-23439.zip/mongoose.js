const express=reuire("express");

const app=express();

const connectDB = require("./connect");
const connection =require("./db/connect");

const PORT=process.env.PORT|| 5500;
const products_routes=require("./routes/products");

app.get("/",(res)=>{

  res.send("Hi, I am Live");
});

app.use("/api/products",products_routes);

const start=async()=>
  {

    try{

      await connectDB();
      app.listen(PORT,() => ) {
        console.log('${PORT}yes I am connected');
        
      });
    }catch (error){

      console.log(error);
    }
  }